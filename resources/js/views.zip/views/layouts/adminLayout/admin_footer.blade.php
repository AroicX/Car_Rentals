<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by <strong>CUSTOMERS WAY</strong>. Designed and Developed by <a href="https://icompassacademyhq.com"><strong>ICOMPASS ACADEMY HQ</strong></a>.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
